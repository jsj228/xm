package com.jiwei.demo.api;

public class Const {
	
	public static String URL = "https://api.dobitrade.com";
	
	public static final String ENCODING = "UTF-8";
	
	public static String ACCESS_KEY = "ba7699e8b60addb3e0iksa5018d7"; // 分配给开发者的应用ACCESS_KEY
	
	public static String VERSION = "1.0"; //接口版本，固定為：1.0
	 
	public static String TYPE = "buy"; //下單類型 buy:買, sale:賣
	
	public static String PRICE = "0.002"; //單價, 不超過8位小數
	
	public static String NUMBER = "10";//數量 不超過8位小數
	
	public static String MARKET = "mcc_btc"; //交易市場
	
	public static String SECRETKEY = "ba7699e8b60addb3e0i"; //

}
