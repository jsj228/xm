package com.jiwei.demo.api;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.message.BasicNameValuePair;

import com.google.common.io.ByteStreams;

public class DobiApi {


	/**
	 * 委托下單
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String order(Map<String, Object> params) throws Exception {

		String accessKey = Const.ACCESS_KEY;
		String timestamp = Long.toString(System.currentTimeMillis());
		String version = Const.VERSION;
		String type = Const.TYPE;
		String price = Const.PRICE;
		String number = Const.NUMBER;
		String market = Const.MARKET;

		params.put("accessKey", accessKey);
		params.put("timestamp", timestamp);
		params.put("version", version);
		params.put("type", type);
		params.put("price", price);
		params.put("number", number);
		params.put("market", market);

		String genHMAC = MapUtil.createParams(MapUtil.sortMapByKey(params));
		String secretKey = Const.SECRETKEY;
		String sign = HmacSHA1.getSignature(genHMAC, secretKey);

		HttpPost httpPost = new HttpPost(Const.URL + "/trade/order");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("accessKey", accessKey));
		nvps.add(new BasicNameValuePair("market", market));
		nvps.add(new BasicNameValuePair("number", number));
		nvps.add(new BasicNameValuePair("price", price));
		nvps.add(new BasicNameValuePair("type", type));
		nvps.add(new BasicNameValuePair("timestamp", timestamp));
		nvps.add(new BasicNameValuePair("version", version));
		nvps.add(new BasicNameValuePair("sign", sign));
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, Const.ENCODING));
		CloseableHttpResponse response = HttpClientFactory.getHttpClient().execute(httpPost,HttpClientContext.create());
		byte[] bytes = ByteStreams.toByteArray(response.getEntity().getContent());
		String retValue = new String(bytes, Const.ENCODING);
		return retValue;
	}

	/**
	 * 撤銷委托單
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String cancel(Map<String, Object> params) throws Exception {

		String accessKey = Const.ACCESS_KEY;
		String timestamp = Long.toString(System.currentTimeMillis());
		String version = Const.VERSION;
		String market = Const.MARKET;
		String id = "1649";

		params.put("accessKey", accessKey);
		params.put("timestamp", timestamp);
		params.put("version", version);
		params.put("market", market);
		params.put("id", id);

		String genHMAC = MapUtil.createParams(MapUtil.sortMapByKey(params));
		String secretKey = Const.SECRETKEY;
		String sign = HmacSHA1.getSignature(genHMAC, secretKey);

		HttpPost httpPost = new HttpPost(Const.URL + "/trade/cancel");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("accessKey", accessKey));
		nvps.add(new BasicNameValuePair("market", market));
		nvps.add(new BasicNameValuePair("id", id));
		nvps.add(new BasicNameValuePair("timestamp", timestamp));
		nvps.add(new BasicNameValuePair("version", version));
		nvps.add(new BasicNameValuePair("sign", sign));
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, Const.ENCODING));
		CloseableHttpResponse response = HttpClientFactory.getHttpClient().execute(httpPost,
				HttpClientContext.create());
		byte[] bytes = ByteStreams.toByteArray(response.getEntity().getContent());
		String retValue = new String(bytes, Const.ENCODING);
		return retValue;
	}
	
	/**
	 * 我的委托單列表
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String myOrders(Map<String, Object> params) throws Exception {

		String accessKey = Const.ACCESS_KEY;
		String timestamp = Long.toString(System.currentTimeMillis());
		String version = Const.VERSION;
		String market = Const.MARKET;
		String page = "1";
		String sortType = "1";

		params.put("accessKey", accessKey);
		params.put("timestamp", timestamp);
		params.put("version", version);
		params.put("market", market);
		params.put("page", page);
		params.put("sortType", sortType);

		String genHMAC = MapUtil.createParams(MapUtil.sortMapByKey(params));
		String secretKey = Const.SECRETKEY;
		String sign = HmacSHA1.getSignature(genHMAC, secretKey);

		HttpPost httpPost = new HttpPost(Const.URL + "/trade/myOrders");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("accessKey", accessKey));
		nvps.add(new BasicNameValuePair("market", market));
		nvps.add(new BasicNameValuePair("page", page));
		nvps.add(new BasicNameValuePair("sortType", sortType));
		nvps.add(new BasicNameValuePair("timestamp", timestamp));
		nvps.add(new BasicNameValuePair("version", version));
		nvps.add(new BasicNameValuePair("sign", sign));
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, Const.ENCODING));
		CloseableHttpResponse response = HttpClientFactory.getHttpClient().execute(httpPost,
				HttpClientContext.create());
		byte[] bytes = ByteStreams.toByteArray(response.getEntity().getContent());
		String retValue = new String(bytes, Const.ENCODING);
		return retValue;
	}
	
	/**
	 * 我的信息
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String myInfo(Map<String, Object> params) throws Exception {

		String accessKey = Const.ACCESS_KEY;
		String timestamp = Long.toString(System.currentTimeMillis());
		String version = Const.VERSION;

		params.put("accessKey", accessKey);
		params.put("timestamp", timestamp);
		params.put("version", version);
	
		String genHMAC = MapUtil.createParams(MapUtil.sortMapByKey(params));
		String secretKey = Const.SECRETKEY;
		String sign = HmacSHA1.getSignature(genHMAC, secretKey);

		HttpPost httpPost = new HttpPost(Const.URL + "/trade/myInfo");
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("accessKey", accessKey));
		nvps.add(new BasicNameValuePair("timestamp", timestamp));
		nvps.add(new BasicNameValuePair("version", version));
		nvps.add(new BasicNameValuePair("sign", sign));
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, Const.ENCODING));
		CloseableHttpResponse response = HttpClientFactory.getHttpClient().execute(httpPost,
				HttpClientContext.create());
		byte[] bytes = ByteStreams.toByteArray(response.getEntity().getContent());
		String retValue = new String(bytes, Const.ENCODING);
		return retValue;
	}
	
	/**
	 * 交易規則
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String rules(Map<String, Object> params) throws Exception {
		String result = HttpClientFactory.doGet(Const.URL + "/trade/rules?market=kkc_eth", 3000);
		return result;
	}
	
	/**
	 * 最新行情
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String quote(Map<String, Object> params) throws Exception {
		String result = HttpClientFactory.doGet(Const.URL + "/market/quote?market=kkc_eth", 3000);
		return result;
	}
	
	/**
	 * 交易市場
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String markets(Map<String, Object> params) throws Exception {
		String result = HttpClientFactory.doGet(Const.URL + "/trade/markets=kkc_eth", 3000);
		return result;
	}
	

	
	

}
