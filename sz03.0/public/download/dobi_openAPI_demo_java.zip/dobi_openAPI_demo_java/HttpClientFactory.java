package com.jiwei.demo.api;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jiwei.demo.utils.MD5HttpUtils;
import com.jiwei.demo.utils.MyX509TrustManager;

public class HttpClientFactory {
	
	private static Logger logger = LoggerFactory.getLogger(HttpClientFactory.class);

	/**
	 * 
	 * @description
	 * @author zfm
	 * @return
	 */
	public static CloseableHttpClient getHttpClient() {
		return HttpClients.custom().setSSLSocketFactory(getSSLConnectionSocketFactory()).build();
	}

	/**
	 * 
	 * @description
	 * @author zfm
	 * @return
	 */
	private static LayeredConnectionSocketFactory getSSLConnectionSocketFactory() {
		X509TrustManager x509mgr = new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}

			@Override
			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}
		};
		SSLContext sslContext = null;
		try {
			sslContext = SSLContext.getInstance(SSLConnectionSocketFactory.SSL);
			sslContext.init(null, new TrustManager[] { x509mgr }, null);
		} catch (NoSuchAlgorithmException e) {

		} catch (KeyManagementException e) {

		}
		return new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	}
	
	public static String doGet(String url, int timeOut) throws Exception {
		if (url.startsWith("https://")) {
			return httpsRequests(url, "GET", null, timeOut, null);
		} else {
			return sendHttpGet(url, timeOut, null);
		}
	}

	private static String sendHttpGet(String url, int timeOut, Object object) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 *
	 * @param requestUrl
	 *            请求地址
	 * @param requestMethod
	 *            GET/POST
	 * @param outputStr
	 *            请求数据
	 * @param timeOut
	 *            超时时间
	 * @return
	 */
	public static String httpsRequests(String requestUrl, String requestMethod, String outputStr, int timeOut,Map<String, Object> params) {
		InputStream inputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader bufferedReader = null;
		HttpsURLConnection conn = null;
		try {
			// 创建SSLContext对象，并使用我们指定的信任管理器初始化
			TrustManager[] tm = { new MyX509TrustManager() };
			SSLContext sslContext = SSLContext.getInstance("SSL", "SunJSSE");
			sslContext.init(null, tm, new java.security.SecureRandom());
			// 从上述SSLContext对象中得到SSLSocketFactory对象
			SSLSocketFactory ssf = sslContext.getSocketFactory();

			URL url = new URL(requestUrl);
			conn = (HttpsURLConnection) url.openConnection();
			conn.setSSLSocketFactory(ssf);

			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.setReadTimeout(timeOut);
			conn.setConnectTimeout(timeOut);
			// 设置请求方式（GET/POST）
			conn.setRequestMethod(requestMethod);
			if (params != null && params.size() > 0) {
				Set<String> keys = params.keySet();
				for (String s : keys) {
					conn.setRequestProperty(s, params.get(s).toString());
				}
			}
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

			// 当outputStr不为null时向输出流写数据
			if (null != outputStr) {
				OutputStream outputStream = conn.getOutputStream();
				// 注意编码格式
				outputStream.write(outputStr.getBytes(MD5HttpUtils.CHARSET_UTF8));
				outputStream.close();
			}

			// 从输入流读取返回内容
			inputStream = conn.getInputStream();
			inputStreamReader = new InputStreamReader(inputStream, MD5HttpUtils.CHARSET_UTF8);
			bufferedReader = new BufferedReader(inputStreamReader);
			String str = null;
			StringBuffer buffer = new StringBuffer();
			while ((str = bufferedReader.readLine()) != null) {
				buffer.append(str);
			}
			String btr = buffer.toString();

			return btr;
		} catch (ConnectException ce) {
			logger.error("连接超时：", ce);
		} catch (Exception e) {
			logger.error("https请求异常：", e);
		} finally {// 释放资源
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (Exception e) {
					e.printStackTrace();
					;
				}
			}
			if (inputStreamReader != null) {
				try {
					inputStreamReader.close();
				} catch (Exception e) {
					e.printStackTrace();
					;
				}
			}
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Exception e) {
					e.printStackTrace();
					;
				}
			}
			if (conn != null) {
				try {
					conn.disconnect();
				} catch (Exception e) {
					e.printStackTrace();
					;
				}
			}
		}
		return null;
	}
	
}
