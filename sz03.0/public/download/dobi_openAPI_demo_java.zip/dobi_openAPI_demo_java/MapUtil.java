package com.jiwei.demo.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * @describe TODO
 */
public class MapUtil {
	/**
	 * Map 按 key 进行排序
	 *
	 * @param map
	 * @return
	 */
	public static Map<String, Object> sortMapByKey(Map<String, Object> map) {
		if (map == null || map.isEmpty()) {
			return null;
		}
		Map<String, Object> sortMap = new TreeMap<String, Object>(new MapKeyComparator());
		sortMap.putAll(map);
		return sortMap;
	}

	/**
	 * Map 按 value 进行排序
	 *
	 * @param map
	 * @return
	 */
	public static Map<String, String> sortMapByValue(Map<String, String> oriMap) {
		if (oriMap == null || oriMap.isEmpty()) {
			return null;
		}
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		List<Map.Entry<String, String>> entryList = new ArrayList<Map.Entry<String, String>>(oriMap.entrySet());
		Collections.sort(entryList, new MapValueComparator());

		Iterator<Map.Entry<String, String>> iter = entryList.iterator();
		Map.Entry<String, String> tmpEntry = null;
		while (iter.hasNext()) {
			tmpEntry = iter.next();
			sortedMap.put(tmpEntry.getKey(), tmpEntry.getValue());
		}
		return sortedMap;
	}
	
	/**
     * 拼接请求参数
     * @param params
     * @return
     * @throws Exception
     */
    public static String createParams(Map<String, Object> params) throws Exception{
        if(params != null && params.size() > 0) {
            Set<String> keys = params.keySet();
            StringBuffer sbf = new StringBuffer();
            for (String key : keys) {
                sbf.append(key).append("=").append(params.get(key)).append("&");
            }
            String result = sbf.toString();
            return result.substring(0, result.length() - 1);
        }
        return null;
    }
    
    /**
     * 用appendStr拼接key=vaule
     * @param map
     * @param appendStr
     * @return
     */
    public static String appendStr(Map<String, Object> map, String appendStr) {
    	if(null == map) {
    		return null;
    	}
    	Iterator<Entry<String, Object>> ite = map.entrySet().iterator();
    	StringBuffer strBuf = new StringBuffer();
    	
    	//false为全部key的vaule为null
    	boolean flag = false;
    	while(ite.hasNext()) {
    		Entry<String, Object> entry = ite.next();
    		Object val = entry.getValue();
    		if(null != val) {
    			flag = true;
    			strBuf.append(entry.toString()).append(appendStr);
    		}
    	}
    	String result = strBuf.toString();
    	if(flag) {
    		return result.substring(0, result.length()-1);
    	}
    	return null;
    }

	/**
	 * 将 Url Params String 转为 Map
	 *
	 * @param param
	 *            aa=11&bb=22&cc=33
	 * @return map
	 */
	public static Map<String, Object> urlParams2Map(String param) {
		Map<String, Object> map = new HashMap<String, Object>();
		if ("".equals(param) || null == param) {
			return map;
		}
		String[] params = param.split("&");
		for (int i = 0; i < params.length; i++) {
			String[] p = params[i].split("=");
			if (p.length == 2) {
				map.put(p[0], p[1]);
			}
		}
		return map;
	}

	/**
	 * 将 map 转为 Url Params String
	 *
	 * @param map
	 * @return aa=11&bb=22&cc=33
	 */
	public static String map2UrlParams(Map<String, String> map, boolean isSort) {
		if (map == null) {
			return "";
		}
		StringBuffer sb = new StringBuffer();
		List<String> keys = new ArrayList<String>(map.keySet());
		if (isSort) {
			Collections.sort(keys);
		}
		for (int i = 0; i < keys.size(); i++) {
			String key = keys.get(i);
			String value = map.get(key).toString();
			sb.append(key + "=" + value);
			sb.append("&");
		}
		String s = sb.toString();
		if (s.endsWith("&")) {
			s = s.substring(0, s.lastIndexOf("&"));
		}
		return s;
	}
}

class MapKeyComparator implements Comparator<String> {
	@Override
	public int compare(String str1, String str2) {
		return str1.compareTo(str2);
	}
}

class MapValueComparator implements Comparator<Map.Entry<String, String>> {
	@Override
	public int compare(Entry<String, String> me1, Entry<String, String> me2) {
		return me1.getValue().compareTo(me2.getValue());
	}

}
