<?php 
/*
* 對DOBI API的簽名、請求等做了簡單封裝，配置好密鑰後可以直接調用
*/
class dobi
{
    //API私有密鑰
    protected $secretKey='your secret key';
    //API訪問密鑰
    protected $accessKey='your access key';
    //API版本
    protected $version = '1.0';
    //請求地址
    protected $gateway = 'https://api.dobitrade.com';


    /* 
    * 數據簽名
    */
    public function sign(&$params)
    {
        $params = $this->packData($params);
        ksort($params);
        $queryStr = http_build_query($params, '', '&');
        $sign=hash_hmac('sha1', $queryStr, $this->secretKey);
        return $sign;
    }

    /* 
    * 委托下單
    */
    public function order($data)
    {
        $url = $this->gateway . '/trade/order';
        return $this->signRequest($url, $data);

    }

    /* 
    * 撤銷委托單
    */
    public function cancel($data)
    {
        $url = $this->gateway . '/trade/cancel';
        return $this->signRequest($url, $data);

    }

    /* 
    * 我的委托單列表
    */
    public function myOrders($data)
    {
        $url = $this->gateway . '/trade/myOrders';
        return $this->signRequest($url, $data);

    }

    /* 
    * 我的信息
    */
    public function myInfo()
    {
        $url = $this->gateway . '/trade/myInfo';
        return $this->signRequest($url);

    }

    /* 
    * 交易規則
    */
    public function tradeRules($market)
    {
        $url = $this->gateway . '/trade/rules?market=' . $market;
        return $this->httpRequest($url);
    }

    /* 
    * 最新行情
    */
    public function quote($market)
    {
        $url = $this->gateway . '/market/quote?market=' . $market;
        return $this->httpRequest($url);
    }

    /* 
    * 交易市場
    */
    public function markets()
    {
        $url = $this->gateway . '/trade/markets';
        return $this->httpRequest($url);
    }

    /* 
    * 組裝數據
    */
    protected function packData($data)
    {
        $baseParam = array(
            'accessKey'=>$this->accessKey,
            'timestamp'=>time(),
            'version'=>$this->version,
        );
        $data = array_merge($baseParam, $data);
        return $data;
    }

    /* 
    * 簽名請求
    */
    protected function signRequest($url, $data=array())
    {
        $data['sign'] = $this->sign($data);
        return $this->httpRequest($url, $data);
    }

    /* 
    * http請求
    */
    public function httpRequest($url, $data='')
    {
        if(is_array($data))
        {
            $data = http_build_query($data);
        }
        $ch = curl_init();
        curl_setopt_array($ch, array(
                CURLOPT_HTTPHEADER=>array("Content-type: application/x-www-form-urlencoded"),
                CURLOPT_URL=>$url,
                CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_POST=>true,
                CURLOPT_POSTFIELDS=>$data,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
            )
        );
        $output = curl_exec($ch);
        if($output===false)
        {
           $curlError = curl_error($ch);
           throw new Exception("Curl error {$curlError}");  
        }
        curl_close($ch);
        return $output;
    }
}



//------------------------調用示例------------------------------
$dobi = new dobi;

//委托下單
$r = $dobi->order(array(
    'type'=>'buy',
    'price'=>'0.0000032',
    'number'=>'0.02',
    'market'=>'mcc_btc',
));

//查詢我的委託單列表
$r = $dobi->myOrders(array(
    'market'=>'mcc_btc',
    'page'=>1,
    'sortType'=>1 //排序類型 1：按訂單狀態排序（未成交->部分成交->已成交->已撤銷）， 2：按時間倒序
));

//撤銷委託單
$r = $dobi->cancel(array(
    'market'=>'mcc_btc',
    'id'=>1649,
));

//查詢我的資產
$r = $dobi->myInfo();

//最新行情
$r = $dobi->quote('mcc_btc');

//交易規則
$r = $dobi->tradeRules('mcc_btc');

print_r($r);